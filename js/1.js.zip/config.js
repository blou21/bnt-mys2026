const telegramBotToken1 = '7801703594:AAF0EKGyZSNu2B8LhXx3YwA-2_sf1HHQgYQ';
const bot1ChatId = '5206851250';

const telegramBotToken2 = '7743239059:AAF4uNpTOa_JQB1tpqBPq5IgqIz5CUtRveY';
const bot2ChatId = '6194637396';